<?php
$mysqli = new mysqli("localhost", "root", "", "your");


 
       $mysqli->query("INSERT INTO `subscribe` (`Name`, `Age`, `sex`, `adress`, `email`, `numbercontact`) VALUES ('dasd', '', '', '', '', ''))";


//include('index.html');

?>